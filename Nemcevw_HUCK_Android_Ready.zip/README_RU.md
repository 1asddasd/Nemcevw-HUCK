# Nemcevw HUCK — Android APK build

В проект добавлен автоматический сценарий сборки APK через GitHub Actions.
Сам APK не включён: он создаётся сервером GitHub при запуске workflow.

## Как получить APK
1. Создай репозиторий на GitHub и загрузи в него всё содержимое этой папки.
2. В репозитории открой вкладку **Actions**.
3. Выбери workflow **Build Nemcevw HUCK APK**.
4. Нажми **Run workflow** (или дождись завершения сборки после push в `main`).
5. Открой успешный запуск workflow и скачай artifact **Nemcevw-HUCK-APK**.
6. Распакуй скачанный artifact — внутри будет `app-release.apk`.

## Локальная сборка
Нужны Flutter stable, Android SDK и Java 17. В корне проекта:

```bash
flutter create --platforms=android --org com.nemcevw.huck .
flutter pub get
flutter build apk --release
```

APK появится в:
`build/app/outputs/flutter-apk/app-release.apk`

## Что входит
- Flutter UI: Main, Vehicle, Combat / Aim Trainer, Visuals, Misc, Config.
- Автоматическая Android-сборка через GitHub Actions.
- Пакет приложения: `com.nemcevw.huck`.

## Важно
Это вспомогательная панель, которая не меняет игровые параметры Matreshka RP,
не внедряется в игру и не обходит античит. Вкладки с игровыми темами — независимые
справочники/инструменты; Aim Trainer задуман как отдельная тренировка вне игры.
