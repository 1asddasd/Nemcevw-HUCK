import 'package:flutter/material.dart';

void main() => runApp(const NemcevwApp());

const accent = Color(0xFFE33B4F);
const panel = Color(0xFF17191F);
const panel2 = Color(0xFF20232B);
const muted = Color(0xFF9298A5);

class NemcevwApp extends StatelessWidget {
  const NemcevwApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nemcevw HUCK',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0D0F13),
        colorScheme: ColorScheme.fromSeed(
          seedColor: accent,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const Dashboard(),
    );
  }
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int selected = 0;
  bool compactMode = true;
  bool showHints = true;
  bool soundEffects = false;
  double uiScale = 1.0;

  final pages = const [
    ('Main', Icons.dashboard_rounded),
    ('Vehicle', Icons.directions_car_filled_rounded),
    ('Combat', Icons.gps_fixed_rounded),
    ('Visuals', Icons.visibility_rounded),
    ('Misc', Icons.widgets_rounded),
    ('Config', Icons.tune_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.sizeOf(context).width >= 760;
    return Scaffold(
      body: SafeArea(
        child: Row(
          children: [
            if (isWide) _sidebar(),
            Expanded(
              child: Column(
                children: [
                  _topbar(),
                  Expanded(child: _content()),
                  if (!isWide) _bottomNav(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sidebar() => Container(
        width: 220,
        decoration: const BoxDecoration(
          color: panel,
          border: Border(right: BorderSide(color: Color(0xFF292D36))),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _brand(),
            const SizedBox(height: 28),
            const Text('WORKSPACE',
                style: TextStyle(color: muted, fontSize: 10, letterSpacing: 1.5)),
            const SizedBox(height: 10),
            ...List.generate(pages.length, (i) => _navItem(i, compact: false)),
            const Spacer(),
            const Text('MATRESHKA RP TOOL',
                style: TextStyle(color: muted, fontSize: 10)),
            const SizedBox(height: 5),
            const Text('VERSION 1.0.0',
                style: TextStyle(color: Color(0xFF626875), fontSize: 10)),
          ],
        ),
      );

  Widget _brand() => Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: accent,
              borderRadius: BorderRadius.circular(11),
            ),
            alignment: Alignment.center,
            child: const Text('N',
                style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 10),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('NEMCEVW',
                  style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
              Text('HUCK SOFTWARE',
                  style: TextStyle(color: muted, fontSize: 9, letterSpacing: 1.2)),
            ],
          )
        ],
      );

  Widget _topbar() => Container(
        height: 68,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        decoration: const BoxDecoration(
          color: panel,
          border: Border(bottom: BorderSide(color: Color(0xFF292D36))),
        ),
        child: Row(
          children: [
            if (MediaQuery.sizeOf(context).width < 760) ...[
              _brand(),
              const Spacer(),
            ] else ...[
              Text(pages[selected].$1,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const Spacer(),
            ],
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: const Color(0xFF173126),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                children: [
                  Icon(Icons.circle, color: Color(0xFF4BD28A), size: 8),
                  SizedBox(width: 7),
                  Text('READY', style: TextStyle(color: Color(0xFF83E5AF), fontSize: 10, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(width: 12),
            const Icon(Icons.more_vert, color: muted),
          ],
        ),
      );

  Widget _content() => SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1000),
          child: _pageBody(),
        ),
      );

  Widget _pageBody() {
    switch (selected) {
      case 0:
        return _mainPage();
      case 1:
        return _vehiclePage();
      case 2:
        return _combatPage();
      case 3:
        return _visualsPage();
      case 4:
        return _miscPage();
      default:
        return _configPage();
    }
  }

  Widget _heading(String title, String subtitle) => Padding(
        padding: const EdgeInsets.only(bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(subtitle, style: const TextStyle(color: muted, fontSize: 12)),
          ],
        ),
      );

  Widget _mainPage() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _heading('Control center', 'ТВОЯ ПАНЕЛЬ ИНСТРУМЕНТОВ'),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF29202A), Color(0xFF191B23)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFF49303A)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('NEMCEVW HUCK',
                          style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 2)),
                      const SizedBox(height: 8),
                      const Text('Всё необходимое —\nв одном месте',
                          style: TextStyle(fontSize: 22, height: 1.15, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 10),
                      const Text('Независимые инструменты для комфортной игры.',
                          style: TextStyle(color: muted, fontSize: 11)),
                      const SizedBox(height: 14),
                      FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: accent),
                        onPressed: () => setState(() => selected = 4),
                        child: const Text('Открыть инструменты'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                const Icon(Icons.bolt_rounded, size: 72, color: Color(0x55E33B4F)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          _sectionTitle('БЫСТРЫЙ ДОСТУП'),
          GridView.count(
            crossAxisCount: MediaQuery.sizeOf(context).width > 600 ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.45,
            children: [
              _quickCard('Vehicle', 'Заметки об автомобиле', Icons.directions_car, 1),
              _quickCard('Aim Trainer', 'Тренировка реакции', Icons.gps_fixed, 2),
              _quickCard('Visuals', 'Вид и масштаб панели', Icons.visibility, 3),
              _quickCard('RP Tools', 'Команды и шаблоны', Icons.content_paste, 4),
              _quickCard('Timer', 'Таймеры и напоминания', Icons.timer, 4),
              _quickCard('Settings', 'Настройки приложения', Icons.settings, 5),
            ],
          ),
        ],
      );

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(text, style: const TextStyle(color: muted, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1.4)),
      );

  Widget _quickCard(String title, String subtitle, IconData icon, int page) => InkWell(
        onTap: () => setState(() => selected = page),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF292D36))),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, color: accent, size: 23),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(color: muted, fontSize: 9)),
              ]),
            ],
          ),
        ),
      );

  Widget _vehiclePage() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _heading('Vehicle', 'СПРАВОЧНИК И ЛИЧНЫЕ ЗАМЕТКИ'),
    _card('Карточка автомобиля', 'Записывай характеристики, любимые модели и заметки о настройках игры.', Icons.directions_car),
    _card('Избранное', 'Список автомобилей, которые хочешь изучить или приобрести в игре.', Icons.star_outline),
    _card('Памятка', 'Храни свои заметки отдельно от игрового клиента.', Icons.sticky_note_2_outlined),
  ]);

  Widget _combatPage() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _heading('Combat / Aim Trainer', 'ОТДЕЛЬНАЯ ТРЕНИРОВКА РЕАКЦИИ'),
    _card('Тренажёр меткости', 'Здесь можно разместить независимую мини-игру для тренировки реакции. Она не взаимодействует с клиентом Matreshka RP.', Icons.gps_fixed),
    _card('Статистика тренировки', 'Время реакции, количество попаданий и личный прогресс в тренажёре.', Icons.query_stats),
  ]);

  Widget _visualsPage() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _heading('Visuals', 'ВНЕШНИЙ ВИД ПРИЛОЖЕНИЯ'),
    _switchTile('Компактный режим', 'Уменьшить отступы интерфейса.', compactMode, (v) => setState(() => compactMode = v)),
    _switchTile('Подсказки', 'Показывать пояснения к инструментам.', showHints, (v) => setState(() => showHints = v)),
    _switchTile('Звуковые эффекты', 'Звуки интерфейса приложения.', soundEffects, (v) => setState(() => soundEffects = v)),
  ]);

  Widget _miscPage() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _heading('Misc tools', 'ПОЛЕЗНЫЕ ПОВСЕДНЕВНЫЕ ИНСТРУМЕНТЫ'),
    _card('RP-команды', 'Личная библиотека команд и текстовых шаблонов.', Icons.terminal),
    _card('Быстрые заметки', 'Сохраняй полезную информацию для ролевой игры.', Icons.note_alt_outlined),
    _card('Таймер', 'Отдельный таймер и напоминания.', Icons.timer_outlined),
  ]);

  Widget _configPage() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    _heading('Configuration', 'НАСТРОЙКИ NEMCEVW HUCK'),
    Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF292D36))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Масштаб интерфейса', style: TextStyle(fontWeight: FontWeight.w700)),
        Slider(value: uiScale, min: 0.8, max: 1.2, divisions: 4, activeColor: accent, onChanged: (v) => setState(() => uiScale = v)),
        Text('${(uiScale * 100).round()}%', style: const TextStyle(color: muted)),
        const SizedBox(height: 12),
        const Text('Версия приложения: 1.0.0', style: TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 5),
        const Text('Платформы: Android / Windows', style: TextStyle(color: muted, fontSize: 12)),
      ]),
    ),
  ]);

  Widget _card(String title, String description, IconData icon) => Container(
    margin: const EdgeInsets.only(bottom: 12),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF292D36))),
    child: Row(children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFF302027), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: accent)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(description, style: const TextStyle(color: muted, fontSize: 11, height: 1.4)),
      ])),
    ]),
  );

  Widget _switchTile(String title, String subtitle, bool value, ValueChanged<bool> onChanged) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(13), border: Border.all(color: const Color(0xFF292D36))),
    child: SwitchListTile(
      contentPadding: EdgeInsets.zero,
      activeThumbColor: Colors.white,
      activeTrackColor: accent,
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
      subtitle: Text(subtitle, style: const TextStyle(color: muted, fontSize: 10)),
      value: value,
      onChanged: onChanged,
    ),
  );

  Widget _navItem(int index, {required bool compact}) {
    final active = selected == index;
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: InkWell(
        onTap: () => setState(() => selected = index),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 11),
          decoration: BoxDecoration(
            color: active ? const Color(0xFF352129) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(children: [
            Icon(pages[index].$2, size: 18, color: active ? accent : muted),
            if (!compact) ...[
              const SizedBox(width: 11),
              Text(pages[index].$1, style: TextStyle(color: active ? Colors.white : muted, fontWeight: active ? FontWeight.w700 : FontWeight.w500, fontSize: 12)),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _bottomNav() => Container(
    height: 65,
    decoration: const BoxDecoration(color: panel, border: Border(top: BorderSide(color: Color(0xFF292D36)))),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: List.generate(pages.length, (i) => IconButton(
        tooltip: pages[i].$1,
        onPressed: () => setState(() => selected = i),
        icon: Icon(pages[i].$2, color: selected == i ? accent : muted),
      )),
    ),
  );
}